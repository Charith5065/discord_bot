import discord
from discord.ext import commands

class Moderation(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(help="Delete the last N messages (default 5).")
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, amount: int = 5):
        await ctx.channel.purge(limit=amount+1)
        m = await ctx.send(f"🧹 Cleared {amount} messages.")
        await m.delete(delay=3)

    @commands.command(help="Kick a member with an optional reason.")
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.kick(reason=reason)
        await ctx.send(f"🦵 {member.mention} has been kicked. Reason: {reason}")

    @commands.command(help="Ban a member with an optional reason.")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.ban(reason=reason)
        await ctx.send(f"🔨 {member.mention} has been banned. Reason: {reason}")

    @commands.command(help="Unban a user by name#discriminator.")
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, *, user_tag: str):
        name, discrim = user_tag.split("#")
        async for ban_entry in ctx.guild.bans():
            user = ban_entry.user
            if (user.name, user.discriminator) == (name, discrim):
                await ctx.guild.unban(user)
                await ctx.send(f"✅ Unbanned {user}")
                return
        await ctx.send("User not found in ban list.")

async def setup(bot: commands.Bot):
    await bot.add_cog(Moderation(bot))