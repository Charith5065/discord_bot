import discord
from discord.ext import commands

WELCOME_CHANNEL_NAME = "general"  # change to your channel

class Welcome(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        channel = discord.utils.get(member.guild.text_channels, name=WELCOME_CHANNEL_NAME)
        if channel:
            await channel.send(f"👋 Welcome to **{member.guild.name}**, {member.mention}!")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        channel = discord.utils.get(member.guild.text_channels, name=WELCOME_CHANNEL_NAME)
        if channel:
            await channel.send(f"👋 {member} left the server. Bye!")

async def setup(bot: commands.Bot):
    await bot.add_cog(Welcome(bot))