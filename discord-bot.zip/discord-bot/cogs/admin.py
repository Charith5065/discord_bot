import discord
from discord.ext import commands

class Admin(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def cog_check(self, ctx):
        # Restrict to server owner or bot owner
        return ctx.author.id in {ctx.guild.owner_id} if ctx.guild else False

    @commands.command(help="Reload a cog. Usage: !reload cogs.fun")
    async def reload(self, ctx, extension: str):
        try:
            await self.bot.unload_extension(extension)
            await self.bot.load_extension(extension)
            await ctx.send(f"♻️ Reloaded `{extension}`")
        except Exception as e:
            await ctx.send(f"❌ Failed to reload `{extension}`: {e}")

    @commands.command(help="Load a cog. Usage: !load cogs.newcog")
    async def load(self, ctx, extension: str):
        try:
            await self.bot.load_extension(extension)
            await ctx.send(f"✅ Loaded `{extension}`")
        except Exception as e:
            await ctx.send(f"❌ Failed to load `{extension}`: {e}")

    @commands.command(help="Unload a cog. Usage: !unload cogs.fun")
    async def unload(self, ctx, extension: str):
        try:
            await self.bot.unload_extension(extension)
            await ctx.send(f"🧹 Unloaded `{extension}`")
        except Exception as e:
            await ctx.send(f"❌ Failed to unload `{extension}`: {e}")

async def setup(bot: commands.Bot):
    await bot.add_cog(Admin(bot))