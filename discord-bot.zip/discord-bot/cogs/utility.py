import time
import discord
from discord.ext import commands

class Utility(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(help="Check bot latency.")
    async def ping(self, ctx):
        await ctx.send(f"🏓 Pong! {round(self.bot.latency * 1000)}ms")

    @commands.command(help="Server information.")
    async def serverinfo(self, ctx):
        g = ctx.guild
        embed = discord.Embed(title=g.name, description="Server Info", color=discord.Color.blurple())
        embed.set_thumbnail(url=g.icon.url if g.icon else discord.Embed.Empty)
        embed.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown")
        embed.add_field(name="Members", value=g.member_count)
        embed.add_field(name="Created", value=g.created_at.strftime('%Y-%m-%d'))
        await ctx.send(embed=embed)

    @commands.command(help="User information.")
    async def userinfo(self, ctx, member: discord.Member=None):
        member = member or ctx.author
        roles = [r.mention for r in member.roles if r.name != "@everyone"]
        embed = discord.Embed(title=str(member), color=member.color if hasattr(member, "color") else discord.Color.green())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="ID", value=member.id)
        embed.add_field(name="Joined", value=member.joined_at.strftime('%Y-%m-%d') if member.joined_at else "Unknown")
        embed.add_field(name="Roles", value=", ".join(roles) if roles else "None", inline=False)
        await ctx.send(embed=embed)

    @commands.command(help="Make the bot say something.")
    @commands.has_permissions(manage_messages=True)
    async def say(self, ctx, *, text: str):
        await ctx.message.delete()
        await ctx.send(text)

async def setup(bot: commands.Bot):
    await bot.add_cog(Utility(bot))