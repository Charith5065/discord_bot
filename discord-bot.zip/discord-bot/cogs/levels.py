import sqlite3
from discord.ext import commands

DB_PATH = "data/levels.db"

def _create_table():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS levels (user_id INTEGER PRIMARY KEY, xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 0)"
    )
    con.commit()
    con.close()

class Levels(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        _create_table()

    def add_xp(self, user_id: int, xp: int):
        con = sqlite3.connect(DB_PATH)
        cur = con.cursor()
        cur.execute("SELECT xp, level FROM levels WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        if row:
            xp_total, level = row
            xp_total += xp
        else:
            xp_total, level = xp, 0

        # Simple leveling formula: 100 * (level + 1)
        needed = 100 * (level + 1)
        if xp_total >= needed:
            level += 1
            xp_total -= needed

        cur.execute("INSERT OR REPLACE INTO levels (user_id, xp, level) VALUES (?, ?, ?)", (user_id, xp_total, level))
        con.commit()
        con.close()

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return
        self.add_xp(message.author.id, 10)

    @commands.command(help="Show your (or another member's) level and XP.")
    async def rank(self, ctx, member=None):
        member = member or ctx.author
        # Try to resolve member if given as mention or id
        if not hasattr(member, "id"):
            try:
                member = await commands.MemberConverter().convert(ctx, member)
            except Exception:
                member = ctx.author

        con = sqlite3.connect(DB_PATH)
        cur = con.cursor()
        cur.execute("SELECT xp, level FROM levels WHERE user_id=?", (member.id,))
        row = cur.fetchone()
        con.close()
        if row:
            xp, level = row
            await ctx.send(f"🏅 {member.mention} — Level **{level}**, XP **{xp}**")
        else:
            await ctx.send(f"{member.mention} has no XP yet. Start chatting!")

async def setup(bot: commands.Bot):
    await bot.add_cog(Levels(bot))