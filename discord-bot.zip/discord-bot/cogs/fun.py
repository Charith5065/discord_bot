import random
from discord.ext import commands

JOKES = [
    "Why did the developer go broke? Because he used up all his cache.",
    "I would tell you a UDP joke... but you might not get it.",
    "There are 10 types of people in the world: those who understand binary and those who don't."
]

class Fun(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(help="Say hello!")
    async def hello(self, ctx):
        await ctx.send(f"Hello {ctx.author.mention}! 😃")

    @commands.command(help="Roll a dice (1-6).")
    async def dice(self, ctx):
        await ctx.send(f"🎲 You rolled a {random.randint(1,6)}")

    @commands.command(help="Flip a coin.")
    async def coin(self, ctx):
        await ctx.send(f"🪙 {random.choice(['Heads', 'Tails'])}")

    @commands.command(help="Tell a random dev joke.")
    async def joke(self, ctx):
        await ctx.send(random.choice(JOKES))

async def setup(bot: commands.Bot):
    await bot.add_cog(Fun(bot))