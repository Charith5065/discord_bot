import os
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv

# Load .env
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("PREFIX", "!")

# Intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Bot
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=commands.DefaultHelpCommand())

# Cogs to load
INITIAL_COGS = [
    "cogs.moderation",
    "cogs.utility",
    "cogs.fun",
    "cogs.welcome",
    "cogs.levels",
    "cogs.admin"
]

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"📦 Loaded cogs: {', '.join(list(bot.cogs.keys()))}")
    await bot.change_presence(activity=discord.Game(name=f'{PREFIX}help'))

async def load_cogs():
    for ext in INITIAL_COGS:
        try:
            await bot.load_extension(ext)
            print(f"Loaded {ext}")
        except Exception as e:
            print(f"Failed to load {ext}: {e}")

@bot.event
async def setup_hook():
    await load_cogs()

if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError("DISCORD_TOKEN not set in .env")
    bot.run(TOKEN)